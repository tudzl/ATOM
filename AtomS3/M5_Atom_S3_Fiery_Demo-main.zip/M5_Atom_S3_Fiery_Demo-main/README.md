# M5 Atom S3: Fiery Demo
An old school fire effect for the M5 Atom S3. (A version for Lilygo T-QT is https://github.com/Sarah-C/T-QT_Fiery_Demo )

There's no PlatformIO version yet, but you should be able to just copy and paste the code into the IDE. (Check the T-QT version's PlatformIO project for details)

The screen button changes the palette.

![image](https://user-images.githubusercontent.com/1586332/211065543-84f58ff5-8a21-4fca-85d7-faad5a920cc9.png)
